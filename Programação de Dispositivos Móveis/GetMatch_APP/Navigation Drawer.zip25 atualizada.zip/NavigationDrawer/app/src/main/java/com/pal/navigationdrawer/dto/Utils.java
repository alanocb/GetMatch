package com.pal.navigationdrawer.dto;

public class Utils {
    public static final String SHARED_PREFERENCE = "app_shared_preference";
}
