package com.pal.navigationdrawer.service;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    public final ApiService api;
    private final String baseUrl = "https://fb47-95-95-216-36.eu.ngrok.io";

    public ApiClient ()
    {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl + "/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(ApiService.class);
    }
}
